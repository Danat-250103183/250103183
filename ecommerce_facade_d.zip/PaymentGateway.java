package com.ecommerce;

public class PaymentGateway {
    public boolean charge(String customerId, double amount) {
        System.out.println("[PaymentGateway] Processing $" + amount + " for " + customerId);
        boolean approved = customerId != null && !customerId.isBlank()
                && Double.isFinite(amount) && amount > 0;
        System.out.println("[PaymentGateway] " + (approved ? "Payment successful" : "Payment declined"));
        return approved;
    }
}
