#!/bin/sh
# Compile everything and run all five runners plus the verification tests.
set -e
rm -rf out && mkdir -p out
javac -Xlint:all -d out $(find src -name "*.java")
for i in 1 2 3 4 5; do
  echo "=============== TASK $i"
  java -cp out task$i.Task${i}Runner
done
echo "=============== TESTS"
java -cp out tests.LabTests
