package com.ecommerce;

public class NotificationService {
    public void sendReceipt(String customerId, double amount) {
        System.out.println("[NotificationService] Receipt of $" + amount + " sent to " + customerId);
    }
}
