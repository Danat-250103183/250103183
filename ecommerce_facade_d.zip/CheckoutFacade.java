package com.ecommerce;

public class CheckoutFacade {
    private final InventoryService inventory;
    private final PaymentGateway payment;
    private final ShippingService shipping;
    private final NotificationService notification;

    public CheckoutFacade() {
        inventory = new InventoryService();
        payment = new PaymentGateway();
        shipping = new ShippingService();
        notification = new NotificationService();
    }

    public boolean placeOrder(String productId, String customerId, String address, double amount) {
        System.out.println("=== [CheckoutFacade] Starting Order Placement Workflow ===");
        if (!inventory.checkStock(productId)) {
            System.out.println("[CheckoutFacade] Order failed: Item out of stock");
            return false;
        }
        if (address == null || address.isBlank()) {
            System.out.println("[CheckoutFacade] Order failed: Invalid delivery address");
            return false;
        }
        inventory.reserve(productId);
        if (!payment.charge(customerId, amount)) {
            inventory.release(productId);
            System.out.println("[CheckoutFacade] Order failed: Payment declined");
            return false;
        }
        shipping.scheduleDelivery(productId, address);
        notification.sendReceipt(customerId, amount);
        System.out.println("=== [CheckoutFacade] Order Workflow Completed Successfully ===");
        return true;
    }
}
