package com.ecommerce;

public class ShippingService {
    public void scheduleDelivery(String productId, String address) {
        if (address == null || address.isBlank()) {
            throw new IllegalArgumentException("Delivery address is required");
        }
        System.out.println("[ShippingService] Delivery scheduled for " + productId + " to " + address);
    }
}
