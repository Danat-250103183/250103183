# Practical Design Patterns: Applied Engineering Lab

Plain JDK (Java 8+ compatible source, standard library only).

| Task | Patterns | Package |
|------|----------|---------|
| 1 | Strategy + Decorator | `task1` |
| 2 | Adapter + Proxy | `task2` |
| 3 | Bridge + Strategy | `task3` |
| 4 | Adapter + Decorator | `task4` |
| 5 | Bridge + Proxy | `task5` |

## Build & run
    ./run_all.sh        # compiles, runs the 5 runners, then tests.LabTests

## Notes on the assignment spec
* Skeleton code was followed where the prose spec and skeleton disagree
  (e.g. `HeaderFooterDecorator` text, `getStorageType()`, `LegacyCurrencyConverter.convert`).
* **Task 4:** `145.00 * 1.085` is `157.32499...` in binary double, so the skeleton's
  `Math.round` yields `$157.32`, not the expected `$157.33`. `CustomsDutyDecorator`
  uses `BigDecimal` + `HALF_UP` to produce the expected result.
* **Task 1:** the published expected trace is not reproducible from the given skeleton.
  With the stack `Base64(HeaderFooter(BaseFileExporter))`, Base64 runs first and
  HeaderFooter wraps the ciphertext, so the header/footer appear in plain text around it.
  The expected trace shows the header *inside* the Base64 blob, and its `236 bytes` count
  matches no layout of this payload. Decorator order is implemented exactly as the runner
  and skeleton specify; swap the nesting order to encode the header too.
* Task 2: cache-hit age varies run to run (legacy feed sleeps 250 ms); not deterministic.
