package tests;

import task1.*;
import task2.*;
import task3.*;
import task4.*;
import task5.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

/** Dependency-free verification tests. Run: java -cp out tests.LabTests */
public class LabTests {
    static int passed = 0, failed = 0;

    static void check(String name, boolean ok) {
        if (ok) { passed++; System.out.println("  PASS  " + name); }
        else    { failed++; System.out.println("  FAIL  " + name); }
    }

    static String capture(Runnable r) {
        PrintStream old = System.out;
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        System.setOut(new PrintStream(buf, true));
        try { r.run(); } finally { System.setOut(old); }
        return buf.toString();
    }

    public static void main(String[] args) throws Exception {
        task1(); task2(); task3(); task4(); task5();
        System.out.printf("%n%d passed, %d failed%n", passed, failed);
        System.exit(failed == 0 ? 0 : 1);
    }

    static void task1() {
        System.out.println("Task 1: Strategy + Decorator");
        String[] h = {"ID", "User"};
        String[][] r = {{"1", "a"}, {"2", "b"}};
        String json = new JsonFormatter().format("T", h, r);
        check("JSON contains title and records", json.contains("\"report\": \"T\"") && json.contains("\"User\": \"b\""));
        String csv = new CsvFormatter().format("T", h, r);
        check("CSV has header and rows", csv.contains("ID,User\n1,a\n2,b\n"));
        String out = capture(() -> new Base64EncryptDecorator(new BaseFileExporter()).export("/x", "hello"));
        String enc = Base64.getEncoder().encodeToString("hello".getBytes(StandardCharsets.UTF_8));
        check("Base64 decorator encodes payload", out.contains("[BASE64_CIPHERTEXT:" + enc + "]"));
        out = capture(() -> new HeaderFooterDecorator(new BaseFileExporter(), "TS").export("/x", "body"));
        check("HeaderFooter decorator wraps payload", out.contains("METADATA HEADER: TS") && out.contains("body") && out.contains("END RECORD"));
        boolean threw = false;
        try { new HeaderFooterDecorator(null, "t"); } catch (IllegalArgumentException e) { threw = true; }
        check("Decorator rejects null wrapped exporter", threw);
    }

    static void task2() {
        System.out.println("Task 2: Adapter + Proxy");
        final int[] calls = {0};
        LegacyStockFeed counting = new LegacyStockFeed() {
            @Override public String fetchRawTickerPacket(String t) { calls[0]++; return super.fetchRawTickerPacket(t); }
        };
        StockProvider adapter = new StockFeedAdapter(counting);
        check("Adapter median AAPL = 183.00", Math.abs(adapter.getMarketPrice("AAPL") - 183.00) < 1e-9);
        check("Adapter median GOOGL = 164.50", Math.abs(adapter.getMarketPrice("GOOGL") - 164.50) < 1e-9);
        check("Adapter status OPEN", "OPEN".equals(adapter.getStatus("AAPL")));
        check("Adapter unknown ticker = 0.0", adapter.getMarketPrice("ZZZ") == 0.0);
        calls[0] = 0;
        StockProvider proxy = new CachedStockProxy(adapter, 300);
        final String[] o = new String[3];
        capture(() -> proxy.getMarketPrice("AAPL"));
        o[0] = capture(() -> proxy.getMarketPrice("AAPL"));
        check("Second call is CACHE HIT", o[0].contains("[CACHE HIT]"));
        check("Cache hit does not call upstream (1 call total)", calls[0] == 1);
        try { Thread.sleep(350); } catch (InterruptedException e) { }
        o[1] = capture(() -> proxy.getMarketPrice("AAPL"));
        check("Expired entry triggers NETWORK FETCH", o[1].contains("[NETWORK FETCH]") && calls[0] == 2);
    }

    static void task3() {
        System.out.println("Task 3: Bridge + Strategy");
        DispatchStrategy bh = new BusinessHoursStrategy();
        check("Business hours: 02:00 sev1 blocked", !bh.shouldDispatch(1, 2));
        check("Business hours: 11:00 sev1 allowed", bh.shouldDispatch(1, 11));
        check("Business hours: 9 and 17 inclusive", bh.shouldDispatch(1, 9) && bh.shouldDispatch(1, 17));
        check("Business hours: 18:00 blocked", !bh.shouldDispatch(1, 18));
        check("Emergency bypass sev5 at 02:00", bh.shouldDispatch(5, 2));
        check("Immediate always true", new ImmediateStrategy().shouldDispatch(1, 3));
        String out = capture(() -> new CriticalSystemAlert(new SmsChannel(), bh).processAlert("+1", "boom", 2));
        check("Critical via SMS delivered, newlines condensed", out.contains("[SMS PROTOCOL -> +1]") && !out.contains("\n!") && out.contains(" -- "));
        out = capture(() -> new DailySummaryAlert(new EmailChannel(), bh).processAlert("a@b", "x", 23));
        check("Summary at 23:00 suppressed", out.contains("[DISPATCH SUPPRESSED]"));
        out = capture(() -> new DailySummaryAlert(new EmailChannel(), bh).processAlert("a@b", "x", 11));
        check("Summary at 11:00 delivered via email", out.contains("[EMAIL PROTOCOL -> a@b]") && out.contains("Daily Digest:"));
    }

    static void task4() {
        System.out.println("Task 4: Adapter + Decorator");
        PricingService base = new CurrencyOrderAdapter(new LegacyForeignOrder("O", 100.0), new LegacyCurrencyConverter(), "USD");
        check("Adapter converts 100 GBP -> 125 USD", Math.abs(base.calculateTotal() - 125.0) < 1e-9);
        check("GiftWrap +5", Math.abs(new GiftWrapDecorator(base).calculateTotal() - 130.0) < 1e-9);
        check("Express +15", Math.abs(new ExpressCourierDecorator(base).calculateTotal() - 140.0) < 1e-9);
        PricingService full = new CustomsDutyDecorator(new ExpressCourierDecorator(new GiftWrapDecorator(base)));
        check("Full stack = 157.33", Math.abs(full.calculateTotal() - 157.33) < 1e-9);
        check("Receipt lists all surcharges", full.getReceiptBreakdown().endsWith("+ [Gift Wrap: $5.00] + [Express Courier: $15.00] + [Customs Duty: 8.5%]"));
        PricingService customsFirst = new ExpressCourierDecorator(new CustomsDutyDecorator(base));
        check("Order matters: customs applied before express = 150.63", Math.abs(customsFirst.calculateTotal() - 150.63) < 1e-9);
    }

    static void task5() {
        System.out.println("Task 5: Bridge + Proxy");
        StorageDriver admin = new StorageDriverProxy(new S3StorageDriver(), new UserSession("u", "ADMIN"));
        StorageDriver guest = new StorageDriverProxy(new NfsStorageDriver(), new UserSession("g", "GUEST"));
        check("Admin gets 4 bytes", capture(() -> { }).isEmpty() && admin.loadRawBlob("a").length == 4);
        check("Guest gets empty payload", guest.loadRawBlob("a").length == 0);
        check("Guest case-insensitive", new StorageDriverProxy(new S3StorageDriver(), new UserSession("g", "guest")).loadRawBlob("a").length == 0);
        check("MEMBER allowed", new StorageDriverProxy(new S3StorageDriver(), new UserSession("m", "MEMBER")).loadRawBlob("a").length == 4);
        check("Proxy storage type wraps real type", admin.getStorageType().equals("PROXY_GUARDED(AMAZON_S3_CLOUD)"));
        String out = capture(() -> new VideoAsset(new NfsStorageDriver(), "v.mp4").render());
        check("Same asset works unguarded on NFS (bridge decoupling)", out.contains("SUCCESS: Video playback buffered 4 bytes via LOCAL_NFS_CLUSTER"));
        out = capture(() -> new AudioAsset(guest, "a.flac").render());
        check("Guest audio fails", out.contains("FAILURE: Audio stream inaccessible."));
    }
}
