package com.ecommerce;

import java.util.HashMap;
import java.util.Map;

public class InventoryService {
    private final Map<String, Integer> stock = new HashMap<>();

    public InventoryService() {
        stock.put("Laptop-X1", 5);
    }

    public boolean checkStock(String productId) {
        boolean available = productId != null && stock.getOrDefault(productId, 0) > 0;
        System.out.println("[InventoryService] Checking stock for " + productId + ": " + (available ? "Available" : "Out of stock"));
        return available;
    }

    public void reserve(String productId) {
        if (!checkStock(productId)) {
            throw new IllegalStateException("Cannot reserve unavailable product: " + productId);
        }
        stock.put(productId, stock.get(productId) - 1);
        System.out.println("[InventoryService] Stock reserved for " + productId);
    }

    public void release(String productId) {
        stock.put(productId, stock.getOrDefault(productId, 0) + 1);
        System.out.println("[InventoryService] Stock released for " + productId);
    }
}
